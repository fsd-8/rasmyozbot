package net.idrok.config;

public class Constant {
    public static final String BOT_TOKEN = "5576943218:AAFLN54blNVTHZ_Xgy-vpYu69swOb3BcfRU";
    public static final String BOT_USERNAME = "rasmyoz_bot";
}
